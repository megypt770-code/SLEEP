# SLEEP 1.5 — approved interfaces / signed release

Android sleep timer for Samsung S21 Ultra / Android 15. Continues the existing `com.robo.sleep` project. No new package identity, expiry actions or permissions. No internet, ads or accounts.

## This revision
- Exactly three selectable looks: Aurora (teal/violet), Lunar (silver moon), Ocean (navy/mint). The twelve earlier looks and their runtime assets are removed.
- Live miniature previews show the idle and running states. Open Appearance from the top-left grid icon or Settings.
- English on first launch; a globe button in Settings offers English and العربية. The app remembers the choice and uses the same language in timer notifications.
- Material Components 1.12.0 with the real `Theme.Material3.Dark.NoActionBar`, MaterialToolbar, MaterialButton, MaterialCardView, MaterialSwitch and MaterialAlertDialogBuilder.
- Rotate for 1–90 minutes, or use TalkBack scroll/progress actions. Countdown uses whole minutes rounded up.
- Start, Pause/Resume, Stop, Extend +10. Pause persists the remaining duration, cancels alarms and the running notification; Resume schedules a new generation and deadline. Stop clears active and paused timers.
- Notification displays only remaining minutes, never an end time. Stop and Extend +10 remain. A dismissed active notification is reposted at the next cosmetic minute update; Doze may delay that non-wakeup update.
- Expiry actions remain opt-in. No Do Not Disturb action. Previous volume restoration is manual.

The attached phone images guide the artwork; controls and numbers are live Android views/Canvas, without copying iOS device chrome or inventing audio playback. Procedural lunar/sea backgrounds are drawn locally, without downloading content.

## Verification / build
JDK 17, Gradle 8.9, Android SDK 35 / Build tools 35.0.0, AGP 8.7.3.

```
./gradlew :app:testDebugUnitTest :app:lintDebug
```

The user explicitly confirmed APK packaging on 2026-10-15. SLEEP-v1.5-S21Ultra.apk was built locally and signed with the original certificate; see docs/BUILD-TEST-REPORT.md for actual checks and limits. No workflow was triggered. Obtain explicit confirmation before packaging future updates.
