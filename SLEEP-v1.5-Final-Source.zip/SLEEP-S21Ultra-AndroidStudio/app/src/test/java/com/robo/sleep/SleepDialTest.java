package com.robo.sleep;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import androidx.appcompat.app.AppCompatDelegate;
import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=35)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class SleepDialTest {
 @Before public void reset(){Context c=RuntimeEnvironment.getApplication();SleepTimerStore.prefs(c).edit().clear().commit();c.getSystemService(android.app.LocaleManager.class).setApplicationLocales(android.os.LocaleList.forLanguageTags("en"));shadowOf((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setCanScheduleExactAlarms(true);}
 @Test public void approvedThemesRenderIdleAndActive()throws Exception{
  try(var ctl=Robolectric.buildActivity(MainActivity.class).setup()){
   MainActivity a=ctl.get();assertEquals(3,SleepThemes.COUNT);
   for(int theme=0;theme<3;theme++){
    SleepThemes.select(a,theme);SleepTimerStore.cancel(a);SleepTimerStore.prefs(a).edit().putInt("chosen_minutes",34).commit();
    a.update();snapshot(a,"approved-"+theme+"-idle");SleepTimerStore.start(a,34);org.robolectric.shadows.ShadowLooper.idleMainLooper(1,java.util.concurrent.TimeUnit.MILLISECONDS);a.update();snapshot(a,"approved-"+theme+"-running");
   }
  }
 }
 @Test public void dragAllThreeAndAccessibilityBounds(){
  try(var ctl=Robolectric.buildActivity(MainActivity.class).setup()){
   MainActivity a=ctl.get();for(int theme=0;theme<3;theme++){
    SleepThemes.select(a,theme);SleepTimerStore.prefs(a).edit().putInt("chosen_minutes",34).commit();SleepDialView v=new SleepDialView(a);FrameLayout parent=new FrameLayout(a);parent.addView(v);v.layout(0,0,390,560);v.draw(new Canvas(Bitmap.createBitmap(390,560,Bitmap.Config.ARGB_8888)));
    touch(v,MotionEvent.ACTION_DOWN,0);for(int i=0;i<=300;i+=10)touch(v,MotionEvent.ACTION_MOVE,i);touch(v,MotionEvent.ACTION_UP,300);assertEquals(90,v.chosenMinutes());
    touch(v,MotionEvent.ACTION_DOWN,0);for(int i=0;i>=-360;i-=10)touch(v,MotionEvent.ACTION_MOVE,i);touch(v,MotionEvent.ACTION_UP,-360);assertEquals(1,v.chosenMinutes());
    v.performAccessibilityAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_FORWARD,null);assertEquals(2,v.chosenMinutes());
   }
  }
 }
 @Test public void minutesOnly(){assertEquals(34,SleepDialView.displayMinutes(33*60000+1));assertEquals(1,SleepDialView.displayMinutes(1));assertEquals(0,SleepDialView.displayMinutes(0));}
 @Test public void pickerMigratesOldThemeAndPreservesTimer()throws Exception{
  Context c=RuntimeEnvironment.getApplication();SleepTimerStore.prefs(c).edit().putInt("ui_theme",11).commit();assertEquals(0,SleepThemes.selected(c));SleepTimerStore.start(c,34);long deadline=SleepTimerStore.finishAt(c),generation=SleepTimerStore.token(c);
  try(var ctl=Robolectric.buildActivity(AppearanceActivity.class).setup()){
   AppearanceActivity a=ctl.get();assertNull(a.findViewById(1005));a.getWindow().getDecorView().findViewWithTag("select_theme_2").performClick();assertEquals(2,SleepThemes.selected(a));assertEquals(deadline,SleepTimerStore.finishAt(a));assertEquals(generation,SleepTimerStore.token(a));snapshot(a,"appearance-picker");
  }
 }
 @Test public void materialSwitchStatesPersistAndBothLocalesRender()throws Exception{
  for(String language:new String[]{"en","ar"}){
   Context c=RuntimeEnvironment.getApplication();SleepLocale.select(c,language);
   try(var ctl=Robolectric.buildActivity(SettingsActivity.class).setup()){
    SettingsActivity a=ctl.get();assertEquals(language,a.getResources().getConfiguration().getLocales().get(0).getLanguage());
    com.google.android.material.materialswitch.MaterialSwitch sw=a.getWindow().getDecorView().findViewWithTag("mute_media");TextView state=a.getWindow().getDecorView().findViewWithTag("mute_media_status");sw.setChecked(false);assertEquals(a.getString(R.string.off_status),state.getText());sw.setChecked(true);assertEquals(a.getString(R.string.on_status),state.getText());sw.jumpDrawablesToCurrentState();assertTrue(SleepTimerStore.option(a,"mute_media",false));assertNull(a.getWindow().getDecorView().findViewWithTag("dnd"));snapshot(a,"settings-"+language);
   }
   try(var ctl=Robolectric.buildActivity(MainActivity.class).setup()){snapshot(ctl.get(),"main-"+language);}
  }
 }
 @Test public void notificationLocaleAndNoEndTime(){Context c=RuntimeEnvironment.getApplication();SleepTimerStore.start(c,34);NotificationManager nm=c.getSystemService(NotificationManager.class);Notification n=shadowOf(nm).getNotification(922);assertEquals("Remaining: 34 min",n.extras.getString(Notification.EXTRA_TEXT));assertFalse(n.extras.getBoolean(Notification.EXTRA_SHOW_WHEN));long deadline=SleepTimerStore.finishAt(c);SleepLocale.select(c,"ar");n=shadowOf(nm).getNotification(922);assertEquals(SleepLocale.context(c).getString(R.string.remaining,34),n.extras.getString(Notification.EXTRA_TEXT));assertEquals(deadline,SleepTimerStore.finishAt(c));}
 @Test public void pauseResumePersistsAndIgnoresOldCompletion(){Context c=RuntimeEnvironment.getApplication();SleepTimerStore.start(c,34);long token=SleepTimerStore.token(c);org.robolectric.shadows.ShadowSystemClock.advanceBy(java.time.Duration.ofMinutes(4));assertTrue(SleepTimerStore.pause(c));assertFalse(SleepTimerStore.running(c));assertEquals(30*60000L,SleepTimerStore.pausedMs(c));assertEquals(0,shadowOf(c.getSystemService(AlarmManager.class)).getScheduledAlarms().size());org.robolectric.shadows.ShadowSystemClock.advanceBy(java.time.Duration.ofHours(2));assertEquals(30*60000L,SleepTimerStore.pausedMs(c));assertFalse(SleepTimerStore.start(c,2));new SleepAlarmReceiver().onReceive(c,new Intent().setAction(SleepTimerStore.FINISH_ACTION).putExtra("timer_token",token));assertTrue(SleepTimerStore.paused(c));assertTrue(SleepTimerStore.resume(c));assertEquals(30*60000L,SleepTimerStore.remainMs(c));assertFalse(SleepTimerStore.paused(c));SleepTimerStore.pause(c);SleepTimerStore.cancel(c);assertFalse(SleepTimerStore.paused(c));assertFalse(SleepTimerStore.resume(c));}
 @Test public void pauseResumePermissionDeniedKeepsRemaining(){Context c=RuntimeEnvironment.getApplication();SleepTimerStore.start(c,1);SleepTimerStore.pause(c);shadowOf(c.getSystemService(AlarmManager.class)).setCanScheduleExactAlarms(false);assertFalse(SleepTimerStore.resume(c));assertEquals(60000L,SleepTimerStore.pausedMs(c));}
 private void touch(View v,int action,double angle){double a=Math.toRadians(angle);MotionEvent e=MotionEvent.obtain(0,0,action,195+(float)Math.cos(a)*150,292+(float)Math.sin(a)*150,0);v.onTouchEvent(e);e.recycle();}
 private void snapshot(android.app.Activity a,String name)throws Exception{View view=a.getWindow().getDecorView();int w=432,h=900;view.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.EXACTLY));view.layout(0,0,w,h);Bitmap image=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);view.draw(new Canvas(image));File file=new File("build/reports/v15/"+name+".png");file.getParentFile().mkdirs();try(FileOutputStream out=new FileOutputStream(file)){image.compress(Bitmap.CompressFormat.PNG,100,out);}}
}
