package com.robo.sleep;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.SystemClock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=35)
public class SleepTimerTest {
    private Context c;
    private AlarmManager alarms;
    private AudioManager audio;
    @Before public void setup() {
        c=RuntimeEnvironment.getApplication();
        SleepTimerStore.prefs(c).edit().clear().commit();
        alarms=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        shadowOf(alarms).setCanScheduleExactAlarms(true);
        audio=(AudioManager)c.getSystemService(Context.AUDIO_SERVICE);
        audio.setStreamVolume(AudioManager.STREAM_MUSIC,5,0);
    }
    private Intent finish(long token) {
        return new Intent(c,SleepAlarmReceiver.class).setAction(SleepTimerStore.FINISH_ACTION).putExtra("timer_token",token);
    }
    @Test public void noActionEnabledByDefault() {
        SleepActions.perform(c);
        assertEquals(5,audio.getStreamVolume(AudioManager.STREAM_MUSIC));
        assertFalse(SleepTimerStore.option(c,"pause_media",false));
        assertFalse(SleepTimerStore.option(c,"lock_screen",false));
    }
    @Test public void notificationReturnsAtNextMinuteWithBothActions() {
        SleepTimerStore.start(c,34);
        android.app.NotificationManager nm=(android.app.NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        android.app.Notification first=shadowOf(nm).getNotification(922);
        assertEquals("Stop",first.actions[0].title.toString());
        assertEquals("Extend +10",first.actions[1].title.toString());
        nm.cancel(922);assertNull(shadowOf(nm).getNotification(922));
        org.robolectric.shadows.ShadowSystemClock.advanceBy(java.time.Duration.ofMinutes(1));
        Intent tick=new Intent(c,SleepAlarmReceiver.class).setAction(SleepTimerStore.REFRESH_ACTION).putExtra("timer_token",SleepTimerStore.token(c));
        new SleepAlarmReceiver().onReceive(c,tick);
        android.app.Notification returned=shadowOf(nm).getNotification(922);
        assertNotNull(returned);
        assertTrue(returned.extras.getCharSequence(android.app.Notification.EXTRA_TEXT).toString().equals("Remaining: 33 min"));
        Intent extend=shadowOf(returned.actions[1].actionIntent).getSavedIntent();
        new SleepAlarmReceiver().onReceive(c,extend);
        assertEquals(43*60_000L,SleepTimerStore.remainMs(c));
        // Re-delivery of the previous notification action cannot extend a second time.
        new SleepAlarmReceiver().onReceive(c,extend);
        assertEquals(43*60_000L,SleepTimerStore.remainMs(c));
        android.app.Notification updated=shadowOf(nm).getNotification(922);
        new SleepAlarmReceiver().onReceive(c,shadowOf(updated.actions[0].actionIntent).getSavedIntent());
        assertFalse(SleepTimerStore.running(c));assertNull(shadowOf(nm).getNotification(922));
        new SleepAlarmReceiver().onReceive(c,tick);assertNull(shadowOf(nm).getNotification(922));
        assertEquals(0,shadowOf(alarms).getScheduledAlarms().size());
    }
    @Test public void refreshSchedulingIsNonWakeupAndAlignedToMinute() {
        SleepTimerStore.start(c,3);
        long deadline=SleepTimerStore.finishAt(c);
        boolean refreshFound=false,expiryFound=false;
        for(org.robolectric.shadows.ShadowAlarmManager.ScheduledAlarm alarm:shadowOf(alarms).getScheduledAlarms()) {
            String action=shadowOf(alarm.operation).getSavedIntent().getAction();
            if(SleepTimerStore.REFRESH_ACTION.equals(action)) {
                refreshFound=true;assertEquals(AlarmManager.ELAPSED_REALTIME,alarm.type);
                assertEquals(deadline-120_000L,alarm.triggerAtTime);
            } else if(SleepTimerStore.FINISH_ACTION.equals(action)) {
                expiryFound=true;assertEquals(AlarmManager.ELAPSED_REALTIME_WAKEUP,alarm.type);
                assertEquals(deadline,alarm.triggerAtTime);
            }
        }
        assertTrue(refreshFound);assertTrue(expiryFound);
        assertEquals(45_000L,SleepTimerStore.nextMinuteDelay(165_000L));
        assertEquals(60_000L,SleepTimerStore.nextMinuteDelay(180_000L));
    }
    @Test public void legacyDndPreferenceCannotActivateDnd() {
        android.app.NotificationManager manager=(android.app.NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        shadowOf(manager).setNotificationPolicyAccessGranted(true);
        manager.setInterruptionFilter(android.app.NotificationManager.INTERRUPTION_FILTER_ALL);
        SleepTimerStore.setOption(c,"dnd",true);
        SleepActions.perform(c);
        assertEquals(android.app.NotificationManager.INTERRUPTION_FILTER_ALL,manager.getCurrentInterruptionFilter());
        try(org.robolectric.android.controller.ActivityController<SettingsActivity> ctl=org.robolectric.Robolectric.buildActivity(SettingsActivity.class).setup()) {
            assertNull(ctl.get().getWindow().getDecorView().findViewWithTag("dnd"));
            assertFalse(SleepTimerStore.prefs(c).contains("dnd"));
        }
    }
    @Test public void scheduleAndStop() {
        assertTrue(SleepTimerStore.start(c,34));
        assertEquals(34*60000L,SleepTimerStore.remainMs(c));
        assertEquals(2,shadowOf(alarms).getScheduledAlarms().size());
        assertFalse(SleepTimerStore.start(c,2));
        SleepTimerStore.cancel(c);
        assertFalse(SleepTimerStore.running(c));
        assertEquals(0,shadowOf(alarms).getScheduledAlarms().size());
    }
    @Test public void staleCompletionCannotAffectNewTimer() {
        SleepTimerStore.start(c,1); long old=SleepTimerStore.token(c);
        SleepTimerStore.cancel(c); SleepTimerStore.start(c,2);
        new SleepAlarmReceiver().onReceive(c,finish(old));
        assertTrue(SleepTimerStore.running(c));
        assertEquals(120000L,SleepTimerStore.remainMs(c));
    }
    @Test public void finishOnlyOnceAndRestoreIsOptIn() {
        SleepTimerStore.setOption(c,"mute_media",true);
        SleepTimerStore.setOption(c,"save_media_volume",true);
        SleepTimerStore.start(c,1); long token=SleepTimerStore.token(c);
        org.robolectric.shadows.ShadowSystemClock.advanceBy(java.time.Duration.ofMinutes(1));
        new SleepAlarmReceiver().onReceive(c,finish(token));
        assertFalse(SleepTimerStore.running(c));
        assertEquals(0,audio.getStreamVolume(AudioManager.STREAM_MUSIC));
        audio.setStreamVolume(AudioManager.STREAM_MUSIC,3,0);
        new SleepAlarmReceiver().onReceive(c,finish(token));
        assertEquals(3,audio.getStreamVolume(AudioManager.STREAM_MUSIC));
        assertTrue(SleepActions.restoreMediaVolume(c));
        assertEquals(5,audio.getStreamVolume(AudioManager.STREAM_MUSIC));
        assertFalse(SleepActions.restoreMediaVolume(c));
    }
    @Test public void noPermissionNoTimerAndBounds() {
        shadowOf(alarms).setCanScheduleExactAlarms(false);
        assertFalse(SleepTimerStore.start(c,34));
        shadowOf(alarms).setCanScheduleExactAlarms(true);
        SleepTimerStore.start(c,1000);
        assertEquals(90*60000L,SleepTimerStore.remainMs(c));
        SleepTimerStore.cancel(c); SleepTimerStore.start(c,0);
        assertEquals(60000L,SleepTimerStore.remainMs(c));
    }
    @Test public void stopPreventsLateCompletion() {
        SleepTimerStore.setOption(c,"mute_media",true);
        SleepTimerStore.start(c,1); long token=SleepTimerStore.token(c);
        SleepTimerStore.cancel(c);
        new SleepAlarmReceiver().onReceive(c,finish(token));
        assertEquals(5,audio.getStreamVolume(AudioManager.STREAM_MUSIC));
    }
    @Test public void bothScreensOpenWithoutCrash() {
        org.robolectric.Robolectric.buildActivity(MainActivity.class).setup().close();
        org.robolectric.Robolectric.buildActivity(SettingsActivity.class).setup().close();
    }
    @Test public void earlyDeliveryDoesNotMute() {
        SleepTimerStore.setOption(c,"mute_media",true);
        SleepTimerStore.start(c,1);
        new SleepAlarmReceiver().onReceive(c,finish(SleepTimerStore.token(c)));
        assertTrue(SleepTimerStore.running(c));
        assertEquals(5,audio.getStreamVolume(AudioManager.STREAM_MUSIC));
    }
    @Test public void sameDurationRestartHasNewGeneration() {
        SleepTimerStore.start(c,1); long old=SleepTimerStore.token(c);
        SleepTimerStore.cancel(c); SleepTimerStore.start(c,1);
        assertNotEquals(old,SleepTimerStore.token(c));
        new SleepAlarmReceiver().onReceive(c,finish(old));
        assertTrue(SleepTimerStore.running(c));
    }
    @Test public void extendAddsToDeadlineAndRejectsOldAlarm() {
        SleepTimerStore.setOption(c,"mute_media",true);
        SleepTimerStore.start(c,34);
        long oldToken=SleepTimerStore.token(c), oldDeadline=SleepTimerStore.finishAt(c);
        org.robolectric.shadows.ShadowSystemClock.advanceBy(java.time.Duration.ofMinutes(4));
        assertTrue(SleepTimerStore.extend(c));
        assertEquals(oldDeadline+600_000L,SleepTimerStore.finishAt(c));
        assertEquals(40*60_000L,SleepTimerStore.remainMs(c));
        assertEquals(44*60_000L,SleepTimerStore.durationMs(c));
        assertEquals(2,shadowOf(alarms).getScheduledAlarms().size());
        assertNotEquals(oldToken,SleepTimerStore.token(c));
        org.robolectric.shadows.ShadowSystemClock.advanceBy(java.time.Duration.ofMinutes(30));
        new SleepAlarmReceiver().onReceive(c,finish(oldToken));
        assertTrue(SleepTimerStore.running(c));
        assertEquals(5,audio.getStreamVolume(AudioManager.STREAM_MUSIC));
        org.robolectric.shadows.ShadowSystemClock.advanceBy(java.time.Duration.ofMinutes(10));
        new SleepAlarmReceiver().onReceive(c,finish(SleepTimerStore.token(c)));
        assertFalse(SleepTimerStore.running(c));
        assertEquals(0,audio.getStreamVolume(AudioManager.STREAM_MUSIC));
    }
    @Test public void multipleExtensionsBeyondNinetyCanBeStopped() {
        SleepTimerStore.start(c,90);
        assertTrue(SleepTimerStore.extend(c)); assertTrue(SleepTimerStore.extend(c));
        assertEquals(110*60_000L,SleepTimerStore.remainMs(c));
        assertEquals(90,SleepTimerStore.prefs(c).getInt("chosen_minutes",0));
        assertEquals(2,shadowOf(alarms).getScheduledAlarms().size());
        long token=SleepTimerStore.token(c); SleepTimerStore.cancel(c);
        new SleepAlarmReceiver().onReceive(c,finish(token));
        assertFalse(SleepTimerStore.running(c));
        assertEquals(0,shadowOf(alarms).getScheduledAlarms().size());
        assertFalse(SleepTimerStore.extend(c));
    }
    @Test public void extendRejectsIdleExpiredAndPermissionDenied() {
        assertFalse(SleepTimerStore.extend(c));
        SleepTimerStore.start(c,1); long deadline=SleepTimerStore.finishAt(c), token=SleepTimerStore.token(c);
        shadowOf(alarms).setCanScheduleExactAlarms(false);
        assertFalse(SleepTimerStore.extend(c));
        assertEquals(deadline,SleepTimerStore.finishAt(c)); assertEquals(token,SleepTimerStore.token(c));
        shadowOf(alarms).setCanScheduleExactAlarms(true);
        org.robolectric.shadows.ShadowSystemClock.advanceBy(java.time.Duration.ofMinutes(1));
        assertFalse(SleepTimerStore.extend(c));
        assertEquals(deadline,SleepTimerStore.finishAt(c));
    }

}
