package com.robo.sleep;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.app.LocaleManager;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.os.LocaleListCompat;
import java.util.Locale;
public final class SleepLocale {
 private SleepLocale(){}
 public static String language(Context c){
  if(Build.VERSION.SDK_INT>=33){android.os.LocaleList list=c.getSystemService(LocaleManager.class).getApplicationLocales();if(!list.isEmpty())return list.get(0).getLanguage();}
  return SleepTimerStore.prefs(c).getString("app_language","en");
 }
 public static Context context(Context c){Configuration config=new Configuration(c.getResources().getConfiguration());Locale l=Locale.forLanguageTag(language(c));config.setLocale(l);config.setLayoutDirection(l);return c.createConfigurationContext(config);}
 public static void select(Context c,String language){
  if(!language.equals("en")&&!language.equals("ar"))return;
  SleepTimerStore.prefs(c).edit().putString("app_language",language).commit();
  if(Build.VERSION.SDK_INT>=33)c.getSystemService(LocaleManager.class).setApplicationLocales(android.os.LocaleList.forLanguageTags(language));
  else AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(language));
  if(SleepTimerStore.running(c))SleepTimerStore.refreshNotification(c);
 }
}