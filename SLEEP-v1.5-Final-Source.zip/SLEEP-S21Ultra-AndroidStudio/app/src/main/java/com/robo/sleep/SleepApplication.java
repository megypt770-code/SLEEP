package com.robo.sleep;
import android.app.Application;
import android.app.LocaleManager;
import android.os.Build;
import android.os.LocaleList;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.os.LocaleListCompat;
public class SleepApplication extends Application {
 @Override public void onCreate(){super.onCreate();
  if(Build.VERSION.SDK_INT>=33){LocaleManager lm=getSystemService(LocaleManager.class);
   if(lm.getApplicationLocales().isEmpty())lm.setApplicationLocales(LocaleList.forLanguageTags(SleepTimerStore.prefs(this).getString("app_language","en")));
  }else AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(SleepTimerStore.prefs(this).getString("app_language","en")));
 }
}