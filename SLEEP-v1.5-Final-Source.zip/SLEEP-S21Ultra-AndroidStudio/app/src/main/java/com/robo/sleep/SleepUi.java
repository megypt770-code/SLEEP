package com.robo.sleep;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
public final class SleepUi {
 private SleepUi(){}
 public static int dp(Context c,float v){return(int)(c.getResources().getDisplayMetrics().density*v+.5f);}
 public static LinearLayout root(AppCompatActivity a){LinearLayout root=new LinearLayout(a);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xff080e16);root.setLayoutDirection("ar".equals(SleepLocale.language(a))?View.LAYOUT_DIRECTION_RTL:View.LAYOUT_DIRECTION_LTR);a.setContentView(root);return root;}
 public static MaterialToolbar toolbar(AppCompatActivity a,LinearLayout root,int title){MaterialToolbar t=new MaterialToolbar(a);t.setTitle(title);t.setTitleTextColor(0xffebeff4);t.setNavigationIcon(R.drawable.ic_back);t.setNavigationContentDescription(R.string.back);t.setNavigationOnClickListener(v->a.finish());root.addView(t,new LinearLayout.LayoutParams(-1,dp(a,56)));return t;}
 public static MaterialButton button(Context c,int label,boolean filled){MaterialButton b=new MaterialButton(c,null,filled?com.google.android.material.R.attr.materialButtonStyle:com.google.android.material.R.attr.materialButtonOutlinedStyle);b.setText(label);b.setAllCaps(false);b.setCornerRadius(dp(c,28));b.setMinHeight(dp(c,52));b.setInsetTop(0);b.setInsetBottom(0);return b;}
 public static TextView text(Context c,int id,int size){TextView t=new TextView(c);t.setText(id);t.setTextSize(size);t.setTextColor(0xffb9c4d0);t.setPadding(dp(c,4),dp(c,9),dp(c,4),dp(c,12));return t;}
 public static void languages(AppCompatActivity a){new MaterialAlertDialogBuilder(a).setTitle(R.string.choose_language).setIcon(R.drawable.ic_globe).setSingleChoiceItems(new String[]{"English","العربية"},"ar".equals(SleepLocale.language(a))?1:0,(d,which)->{d.dismiss();SleepLocale.select(a,which==1?"ar":"en");}).setNegativeButton(R.string.done,null).show();}
 public static void appearance(Context c){c.startActivity(new Intent(c,AppearanceActivity.class));}
}
