package com.robo.sleep;
import android.content.Context;
public final class SleepThemes {
 public static final int COUNT=3;
 private static final int[] NAMES={R.string.theme_0,R.string.theme_1,R.string.theme_2};
 private SleepThemes(){}
 public static int selected(Context c){
  android.content.SharedPreferences p=SleepTimerStore.prefs(c);
  if(!p.getBoolean("approved_themes_v15",false)){p.edit().putInt("ui_theme",0).putBoolean("approved_themes_v15",true).apply();return 0;}
  return Math.max(0,Math.min(COUNT-1,p.getInt("ui_theme",0)));
 }
 public static void select(Context c,int id){if(id>=0&&id<COUNT)SleepTimerStore.prefs(c).edit().putInt("ui_theme",id).putBoolean("approved_themes_v15",true).apply();}
 public static String name(Context c,int id){return c.getString(NAMES[Math.max(0,Math.min(2,id))]);}
}