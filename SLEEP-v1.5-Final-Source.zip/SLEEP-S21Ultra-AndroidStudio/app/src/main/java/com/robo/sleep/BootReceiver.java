package com.robo.sleep;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            // Monotonic times are invalid across reboot; avoid mistakenly muting the phone.
            SleepTimerStore.clear(context);
        }
    }
}
