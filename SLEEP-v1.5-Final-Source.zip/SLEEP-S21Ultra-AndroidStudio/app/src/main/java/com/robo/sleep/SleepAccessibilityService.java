package com.robo.sleep;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

public class SleepAccessibilityService extends AccessibilityService {
    private static volatile SleepAccessibilityService active;
    @Override protected void onServiceConnected() { super.onServiceConnected(); active = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { } // No content collection or inspection
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (active == this) active = null; super.onDestroy(); }
    public static boolean goHome() {
        SleepAccessibilityService service = active;
        return service != null && service.performGlobalAction(GLOBAL_ACTION_HOME);
    }
}
