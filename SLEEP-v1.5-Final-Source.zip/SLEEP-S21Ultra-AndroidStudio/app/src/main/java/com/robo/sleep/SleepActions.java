package com.robo.sleep;

import android.app.NotificationManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.media.AudioManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.SystemClock;
import android.view.KeyEvent;
import java.util.List;

public final class SleepActions {
    private SleepActions() { }
    public static void perform(Context c) {
        if (SleepTimerStore.option(c, "pause_media", false)) pauseMedia(c);
        if (SleepTimerStore.option(c, "mute_media", false)) muteMusic(c);
        if (SleepTimerStore.option(c, "silent_phone", false)) silenceRinger(c);
        if (SleepTimerStore.option(c, "go_home", false)) {
            try { SleepAccessibilityService.goHome(); } catch (RuntimeException ignored) { }
        }
        if (SleepTimerStore.option(c, "lock_screen", false)) lock(c);
    }
    private static void pauseMedia(Context c) {
        boolean found = false;
        try {
            MediaSessionManager mm = (MediaSessionManager)c.getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> list = mm.getActiveSessions(new ComponentName(c, SleepNotificationListener.class));
            for (MediaController ctl : list) {
                PlaybackState ps = ctl.getPlaybackState();
                if (ps == null || ps.getState() == PlaybackState.STATE_PLAYING ||
                    ps.getState() == PlaybackState.STATE_BUFFERING || ps.getState() == PlaybackState.STATE_FAST_FORWARDING) {
                    try { ctl.getTransportControls().pause(); found = true; } catch (RuntimeException ignored) { }
                }
            }
        } catch (SecurityException ignored) { } catch (RuntimeException ignored) { }
        // Fallback media key is widely supported but cannot guarantee all YouTube builds will respond.
        {
            try {
                AudioManager am = (AudioManager)c.getSystemService(Context.AUDIO_SERVICE);
                long now = SystemClock.uptimeMillis();
                am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0));
                am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0));
            } catch (RuntimeException ignored) { }
        }
    }
    private static void muteMusic(Context c) {
        try {
            AudioManager am = (AudioManager)c.getSystemService(Context.AUDIO_SERVICE);
            int before = am.getStreamVolume(AudioManager.STREAM_MUSIC);
            if (before > 0) {
                if (SleepTimerStore.option(c, "save_media_volume", false))
                    SleepTimerStore.prefs(c).edit().putInt("previous_media_volume", before).commit();
                else SleepTimerStore.prefs(c).edit().remove("previous_media_volume").commit();
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
            }
        } catch (SecurityException ignored) { }
    }
    public static boolean restoreMediaVolume(Context c) {
        int previous = SleepTimerStore.prefs(c).getInt("previous_media_volume", -1);
        if (previous < 0) return false;
        try {
            AudioManager am = (AudioManager)c.getSystemService(Context.AUDIO_SERVICE);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.min(previous, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)), 0);
            SleepTimerStore.prefs(c).edit().remove("previous_media_volume").apply();
            return true;
        } catch (SecurityException e) { return false; }
    }
    public static boolean notificationPolicyGranted(Context c) {
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm.isNotificationPolicyAccessGranted();
    }
    private static void silenceRinger(Context c) {
        try {
            if (!notificationPolicyGranted(c)) return;
            AudioManager am = (AudioManager)c.getSystemService(Context.AUDIO_SERVICE);
            am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
        } catch (SecurityException ignored) { }
    }
    public static boolean adminEnabled(Context c) {
        DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
        return dpm.isAdminActive(new ComponentName(c, SleepAdminReceiver.class));
    }
    private static void lock(Context c) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (adminEnabled(c)) dpm.lockNow();
        } catch (SecurityException ignored) { }
    }
}
