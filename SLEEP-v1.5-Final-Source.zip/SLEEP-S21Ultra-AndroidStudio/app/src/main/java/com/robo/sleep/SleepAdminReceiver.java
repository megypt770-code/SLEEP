package com.robo.sleep;

import android.app.admin.DeviceAdminReceiver;
public class SleepAdminReceiver extends DeviceAdminReceiver { }
