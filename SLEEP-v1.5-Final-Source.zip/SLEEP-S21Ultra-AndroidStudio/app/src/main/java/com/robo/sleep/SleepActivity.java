package com.robo.sleep;
import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
/** Use the saved per-app locale immediately, including before framework recreation. */
public abstract class SleepActivity extends AppCompatActivity {
 @Override protected void attachBaseContext(Context base){super.attachBaseContext(SleepLocale.context(base));}
 @Override protected void onResume(){super.onResume();String expected=SleepLocale.language(this);String actual=getResources().getConfiguration().getLocales().get(0).getLanguage();if(!expected.equals(actual))recreate();}
}
