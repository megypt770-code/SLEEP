package com.robo.sleep;
import android.os.Bundle;
import android.content.res.ColorStateList;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.button.MaterialButton;
public class AppearanceActivity extends SleepActivity {
 @Override public void onCreate(Bundle state){super.onCreate(state);render();}
 private void render(){
  LinearLayout root=SleepUi.root(this);SleepUi.toolbar(this,root,R.string.appearance);
  ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(20,8,20,24);scroll.addView(list);
  list.addView(SleepUi.text(this,R.string.appearance_hint,14));
  int current=SleepThemes.selected(this);
  for(int i=0;i<SleepThemes.COUNT;i++){
   final int id=i;boolean selected=i==current;
   MaterialCardView card=new MaterialCardView(this);card.setTag("theme_card_"+i);card.setRadius(SleepUi.dp(this,24));card.setCardBackgroundColor(0xff111c27);card.setStrokeWidth(SleepUi.dp(this,selected?2:1));card.setStrokeColor(selected?0xff8cdccd:0xff3b4855);
   LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=SleepUi.dp(this,18);list.addView(card,cp);
   LinearLayout body=new LinearLayout(this);body.setPadding(16,16,16,18);body.setOrientation(LinearLayout.VERTICAL);card.addView(body);
   LinearLayout images=new LinearLayout(this);body.addView(images);
   for(boolean running:new boolean[]{false,true}){SleepDialView v=new SleepDialView(this);v.preview(i,running);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(0,SleepUi.dp(this,235),1);vp.setMargins(4,0,4,0);images.addView(v,vp);}
   TextView name=new TextView(this);name.setText(SleepThemes.name(this,i)+(selected?"  ✓":""));name.setTextSize(20);name.setTextColor(0xffe7eef4);name.setPadding(12,12,12,8);body.addView(name);
   MaterialButton select=SleepUi.button(this,selected?R.string.selected:R.string.select,selected);select.setTag("select_theme_"+i);select.setContentDescription(getString(selected?R.string.selected:R.string.select)+" "+SleepThemes.name(this,i));body.addView(select,new LinearLayout.LayoutParams(-1,SleepUi.dp(this,48)));select.setOnClickListener(v->{SleepThemes.select(this,id);render();});
   card.setContentDescription(SleepThemes.name(this,i));
  }
 }
}
