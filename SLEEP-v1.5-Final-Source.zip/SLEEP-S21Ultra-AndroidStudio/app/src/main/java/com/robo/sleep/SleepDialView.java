package com.robo.sleep;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
import android.os.Bundle;
import java.util.Random;

/** Live timer artwork: reference colours and geometry, no baked-in controls or digits. */
public class SleepDialView extends View {
    private final Paint paint=new Paint(3);
    private int minutes, previewTheme=-1;
    private boolean previewRunning, dragging;
    private double lastAngle,dragMinutes;
    private float scale=1,ox,oy;
    private static final float CX=195,CY=292,RADIUS=148;
    public SleepDialView(Context c){super(c);minutes=Math.max(1,Math.min(90,SleepTimerStore.prefs(c).getInt("chosen_minutes",34)));setFocusable(true);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);updateDescription();}
    public void preview(int theme,boolean running){previewTheme=theme;previewRunning=running;setFocusable(false);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);invalidate();}
    public int chosenMinutes(){return minutes;}
    static int displayMinutes(long ms){return(int)Math.max(0,(ms+59999)/60000);}
    private void color(int c){paint.reset();paint.setAntiAlias(true);paint.setColor(c);}
    private void text(Canvas c,String s,float x,float y,float size,int col){color(col);paint.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL));paint.setTextSize(size);paint.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,paint);}
    @Override protected void onMeasure(int w,int h){super.onMeasure(w,h);}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
        int theme=previewTheme>=0?previewTheme:SleepThemes.selected(getContext());
        boolean active=previewTheme>=0?previewRunning:SleepTimerStore.running(getContext());
        boolean paused=previewTheme<0&&SleepTimerStore.paused(getContext());
        long remaining=paused?SleepTimerStore.pausedMs(getContext()):SleepTimerStore.remainMs(getContext());
        int shown=previewTheme>=0?34:active||paused?displayMinutes(remaining):minutes;
        float progress=previewTheme>=0?(previewRunning?.72f:34/90f):active||paused?(float)((double)remaining/SleepTimerStore.durationMs(getContext())):minutes/90f;
        progress=Math.max(0,Math.min(1,progress));
        int bg=theme==2?0xff06131f:0xff090b0e;
        canvas.drawColor(bg);scale=Math.min(getWidth()/390f,getHeight()/560f);ox=(getWidth()-390*scale)/2;oy=(getHeight()-560*scale)/2;
        canvas.save();canvas.translate(ox,oy);canvas.scale(scale,scale);
        Canvas c=canvas;
        if(theme==2)sea(c,active);else if(theme==1)terrain(c);
        // Calm crescent header. No fake status bar from the reference phone mockups.
        crescent(c,195,35,13,theme==2?0xff88cfc4:0xffd6d9dd,bg);
        text(c,getContext().getString(R.string.sleep_timer),195,79,18,0xffe9ebee);
        text(c,getContext().getString(paused?R.string.timer_paused:active?R.string.timer_running:R.string.select_time),195,107,13,theme==2?0xff9fcfc9:0xffa2a7af);
        RectF dial=new RectF(CX-RADIUS,CY-RADIUS,CX+RADIUS,CY+RADIUS);
        color(theme==2?0xff243440:0xff303236);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(22);c.drawOval(dial,paint);
        color(0xff4b4e54);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.7f);c.drawCircle(CX,CY,RADIUS+27,paint);
        if(theme==0){
            for(int i=0;i<=18;i++){double a=Math.toRadians(45+i*5);float rr=RADIUS+27;color(0xff7c818a);paint.setStrokeWidth(i%3==0?2:1);c.drawLine(CX+(float)Math.cos(a)*rr,CY+(float)Math.sin(a)*rr,CX+(float)Math.cos(a)*(rr+(i%3==0?9:4)),CY+(float)Math.sin(a)*(rr+(i%3==0?9:4)),paint);}
            text(c,"30",195,491,12,0xff969da7);text(c,"15",66,437,12,0xff969da7);text(c,"60",324,437,12,0xff969da7);text(c,"90",195,133,12,0xff969da7);
        }
        if(theme==1)moon(c,195,222,43);
        int ink=theme==0?0xff83e1d7:theme==2?0xffb4ece3:0xfff2f3f4;
        color(ink);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(active?22:5);paint.setStrokeCap(Paint.Cap.ROUND);
        if(theme==0)paint.setShader(new SweepGradient(CX,CY,new int[]{0xffb594ed,0xffa2a9ed,0xff67d8d0,0xffb594ed,0xffb594ed},new float[]{0,.25f,.5f,.75f,1}));
        else if(theme==2)paint.setShader(new LinearGradient(40,440,340,140,new int[]{0xff70d2bd,0xffa6e9c7},null,Shader.TileMode.CLAMP));
        c.drawArc(dial,-90,progress*360,false,paint);paint.setShader(null);
        if(!active){double a=Math.toRadians(-90+progress*360);float x=CX+(float)Math.cos(a)*RADIUS,y=CY+(float)Math.sin(a)*RADIUS;color(theme==1?0xffd1d4d7:0xff82d9cb);c.drawCircle(x,y,15,paint);color(0x55ffffff);c.drawCircle(x-3,y-4,5,paint);}
        text(c,String.valueOf(shown),195,theme==1?345:319,96,ink);
        text(c,getContext().getString(R.string.minutes),195,theme==1?381:359,15,0xffbfc5ce);
        if(!active&&!paused&&previewTheme<0)text(c,getContext().getString(R.string.rotate_hint),195,532,12,0xff949fab);
        canvas.restore();
    }
    private void crescent(Canvas c,float x,float y,float radius,int ink,int bg){color(ink);c.drawCircle(x,y,radius,paint);color(bg);c.drawCircle(x+7,y-5,radius-1,paint);}
    private void moon(Canvas c,float x,float y,float radius){
        int save=c.save();c.clipPath(circle(x,y,radius));
        color(0xff999da0);paint.setShader(new RadialGradient(x-12,y-18,radius*1.7f,new int[]{0xffd4d7d7,0xff868b90,0xff1d242b},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,radius,paint);
        Random r=new Random(37);for(int i=0;i<140;i++){float xx=x-radius+r.nextFloat()*radius*2,yy=y-radius+r.nextFloat()*radius*2;color(i%3==0?0x40808084:0x26505255);c.drawCircle(xx,yy,1+r.nextFloat()*7,paint);}
        color(0xff080b10);paint.setShader(new LinearGradient(0,y-10,0,y+radius,new int[]{0x00080b10,0xff080b10},null,Shader.TileMode.CLAMP));c.drawRect(x-radius,y-radius,x+radius,y+radius,paint);c.restoreToCount(save);
    }
    private Path circle(float x,float y,float radius){Path p=new Path();p.addCircle(x,y,radius,Path.Direction.CW);return p;}
    private void sea(Canvas c,boolean running){
        if(!running)return;
        color(0xff102a3a);paint.setShader(new LinearGradient(0,270,0,560,new int[]{0x0034586c,0xff254858,0xff071724},new float[]{0,.52f,1},Shader.TileMode.CLAMP));c.drawRect(0,270,390,560,paint);
        Random random=new Random(118);
        for(int row=0;row<33;row++){float y=343+row*6.6f;Path wave=new Path();wave.moveTo(0,y);for(int x=0;x<=390;x+=6)wave.lineTo(x,y+(float)Math.sin(x*.037+row*.85)*(1.5f+row*.15f)+random.nextFloat()*1.6f);color(row%3==0?0x406e98a9:0x302a5367);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.6f+row*.03f);c.drawPath(wave,paint);}
    }
    private void terrain(Canvas c){
        color(0xff0b0c0e);paint.setShader(new LinearGradient(0,410,0,560,new int[]{0x000d0e11,0xff25282e},null,Shader.TileMode.CLAMP));c.drawRect(0,410,390,560,paint);
        Random random=new Random(73);for(int row=0;row<45;row++){float y=460+row*2.2f;Path p=new Path();p.moveTo(0,y);for(int x=0;x<=390;x+=5)p.lineTo(x,y+(float)Math.sin(x*.027+row*.25f)*9+random.nextFloat()*5);color(row%4==0?0x45676c72:0x25393d42);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.7f);c.drawPath(p,paint);}
        color(0xff090b0e);paint.setShader(new LinearGradient(0,495,0,560,new int[]{0x00090b0e,0xff090b0e},null,Shader.TileMode.CLAMP));c.drawRect(0,495,390,560,paint);
    }
    @Override public boolean performClick(){super.performClick();return true;}
    private boolean editable(){return previewTheme<0&&!SleepTimerStore.running(getContext())&&!SleepTimerStore.paused(getContext());}
    @Override public boolean onTouchEvent(MotionEvent event){
        if(previewTheme>=0)return false;
        float x=(event.getX()-ox)/Math.max(scale,.01f),y=(event.getY()-oy)/Math.max(scale,.01f);
        switch(event.getActionMasked()){
         case MotionEvent.ACTION_DOWN: if(!editable()||Math.hypot(x-CX,y-CY)<75||Math.hypot(x-CX,y-CY)>RADIUS+35)return false;dragging=true;lastAngle=Math.toDegrees(Math.atan2(y-CY,x-CX));dragMinutes=minutes;getParent().requestDisallowInterceptTouchEvent(true);return true;
         case MotionEvent.ACTION_MOVE: if(!dragging)return false;double angle=Math.toDegrees(Math.atan2(y-CY,x-CX)),delta=angle-lastAngle;if(delta>180)delta-=360;if(delta< -180)delta+=360;lastAngle=angle;dragMinutes=Math.max(1,Math.min(90,dragMinutes+delta/4));setMinutes((int)Math.round(dragMinutes));return true;
         case MotionEvent.ACTION_UP: if(!dragging)return false;dragging=false;performClick();getParent().requestDisallowInterceptTouchEvent(false);return true;
         case MotionEvent.ACTION_CANCEL: dragging=false;return true;
        }return false;
    }
    private void setMinutes(int value){value=Math.max(1,Math.min(90,value));if(value==minutes)return;minutes=value;SleepTimerStore.prefs(getContext()).edit().putInt("chosen_minutes",minutes).apply();updateDescription();performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);invalidate();}
    private void updateDescription(){setContentDescription(getContext().getString(R.string.dial_accessibility)+" "+minutes+" "+getContext().getString(R.string.minutes));}
    @Override public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(info);info.setClassName("android.widget.SeekBar");info.setRangeInfo(AccessibilityNodeInfo.RangeInfo.obtain(AccessibilityNodeInfo.RangeInfo.RANGE_TYPE_INT,1,90,minutes));if(editable()){info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD);info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD);info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS);}}
    @Override public boolean performAccessibilityAction(int action,Bundle args){if(editable()){if(action==AccessibilityNodeInfo.ACTION_SCROLL_FORWARD){setMinutes(minutes+1);return true;}if(action==AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD){setMinutes(minutes-1);return true;}if(action==AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS.getId()&&args!=null){setMinutes(Math.round(args.getFloat(AccessibilityNodeInfo.ACTION_ARGUMENT_PROGRESS_VALUE)));return true;}}return super.performAccessibilityAction(action,args);}
}
