package com.robo.sleep;
import android.app.admin.DevicePolicyManager;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;
public class SettingsActivity extends SleepActivity {
 private LinearLayout content;
 @Override public void onCreate(Bundle state){super.onCreate(state);render();}
 private void render(){SleepTimerStore.prefs(this).edit().remove("dnd").apply();LinearLayout root=SleepUi.root(this);SleepUi.toolbar(this,root,R.string.settings);
  ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(20),dp(8),dp(20),dp(24));scroll.addView(content);
  MaterialButton language=button(R.string.language,()->SleepUi.languages(this));language.setIconResource(R.drawable.ic_globe);language.setText(getString(R.string.language)+" · "+("ar".equals(SleepLocale.language(this))?"العربية":"English"));language.setTag("language_picker");
  MaterialButton appearance=button(R.string.appearance,()->SleepUi.appearance(this));appearance.setIconResource(R.drawable.ic_appearance);
  // Current live miniature makes the destination easy to recognise.
  MaterialCardView preview=new MaterialCardView(this);preview.setRadius(dp(22));preview.setCardBackgroundColor(0xff101822);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(180));pp.bottomMargin=dp(14);content.addView(preview,pp);SleepDialView mini=new SleepDialView(this);mini.preview(SleepThemes.selected(this),true);preview.addView(mini,new android.widget.FrameLayout.LayoutParams(-1,-1));preview.setContentDescription(getString(R.string.appearance)+": "+SleepThemes.name(this,SleepThemes.selected(this)));preview.setOnClickListener(v->SleepUi.appearance(this));
  section(R.string.actions_title);note(R.string.settings_hint);
  option("pause_media",R.string.pause_media,R.string.pause_media_desc);option("mute_media",R.string.mute_media,R.string.mute_media_desc);option("silent_phone",R.string.silent_phone,R.string.silent_phone_desc);option("go_home",R.string.go_home,R.string.go_home_desc);option("lock_screen",R.string.lock_screen,R.string.lock_screen_desc);note(R.string.close_apps_limit);
  section(R.string.permissions);note(R.string.permission_hint);
  grant(R.string.exact_alarm,SleepTimerStore.hasExactAlarmPermission(this),()->{if(Build.VERSION.SDK_INT>=31)open(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));});
  grant(R.string.media_access,listenerEnabled(this),()->open(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
  grant(R.string.ringer_access,SleepActions.notificationPolicyGranted(this),()->open(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)));note(R.string.silent_policy_hint);
  grant(R.string.accessibility,accessibilityEnabled(this),()->open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
  grant(R.string.admin,SleepActions.adminEnabled(this),()->{Intent i=new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,new ComponentName(this,SleepAdminReceiver.class)).putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,getString(R.string.device_admin_explanation));open(i);});
  grant(R.string.notifications,Build.VERSION.SDK_INT<33||checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED,()->{if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},19);else open(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));});
  button(R.string.battery,()->open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))));note(R.string.battery_hint);note(R.string.notification_hint);
  section(R.string.sound);option("save_media_volume",R.string.save_media_volume,R.string.save_media_volume_desc);button(R.string.restore_volume,()->Toast.makeText(this,SleepActions.restoreMediaVolume(this)?R.string.restored:R.string.no_saved_volume,Toast.LENGTH_SHORT).show());note(R.string.privacy);note(R.string.version);
 }
 private int dp(float x){return SleepUi.dp(this,x);}
 private void section(int id){TextView t=SleepUi.text(this,id,22);t.setTextColor(0xffb2f2e4);content.addView(t);}
 private void note(int id){content.addView(SleepUi.text(this,id,13));}
 private MaterialButton button(int id,Runnable click){MaterialButton b=SleepUi.button(this,id,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);content.addView(b,lp);b.setOnClickListener(v->click.run());return b;}
 private void grant(int id,boolean granted,Runnable click){MaterialButton b=button(id,click);b.setText(getString(granted?R.string.ready:R.string.allow,getString(id)));b.setIconResource(granted?R.drawable.ic_check:R.drawable.ic_permission);}
 private void option(String key,int title,int description){
  MaterialCardView card=new MaterialCardView(this);card.setRadius(dp(22));card.setStrokeWidth(dp(1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(12);content.addView(card,lp);
  LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(16),dp(12),dp(16),dp(12));card.addView(body);
  MaterialSwitch sw=new MaterialSwitch(this);sw.setTag(key);sw.setText(title);sw.setTextSize(16);sw.setTextColor(0xffeaf1f7);sw.setMinHeight(dp(52));sw.setChecked(SleepTimerStore.option(this,key,false));body.addView(sw,new LinearLayout.LayoutParams(-1,-2));
  TextView status=SleepUi.text(this,sw.isChecked()?R.string.on_status:R.string.off_status,13);status.setTag(key+"_status");body.addView(status);body.addView(SleepUi.text(this,description,13));
  Runnable update=()->{boolean on=sw.isChecked();status.setText(on?R.string.on_status:R.string.off_status);status.setTextColor(on?0xff9ee4d4:0xffb6c1cf);card.setCardBackgroundColor(on?0xff17372f:0xff131e2a);card.setStrokeColor(on?0xff8cdccd:0xff3c4b5c);androidx.core.view.ViewCompat.setStateDescription(sw,getString(on?R.string.on_status:R.string.off_status));};
  update.run();sw.setOnCheckedChangeListener((b,on)->{SleepTimerStore.setOption(this,key,on);update.run();});
 }
 private void open(Intent i){try{startActivity(i);}catch(RuntimeException e){Toast.makeText(this,R.string.permission_unavailable,Toast.LENGTH_LONG).show();}}
 static boolean listenerEnabled(Context c){String s=Settings.Secure.getString(c.getContentResolver(),"enabled_notification_listeners");return s!=null&&s.contains(new ComponentName(c,SleepNotificationListener.class).flattenToString());}
 static boolean accessibilityEnabled(Context c){String s=Settings.Secure.getString(c.getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);return s!=null&&s.contains(new ComponentName(c,SleepAccessibilityService.class).flattenToString());}
 private boolean refreshOnResume;
 @Override protected void onPause(){super.onPause();refreshOnResume=true;}
 @Override protected void onResume(){super.onResume();if(refreshOnResume){refreshOnResume=false;render();}}
 @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){super.onRequestPermissionsResult(code,permissions,results);render();}
}
