package com.robo.sleep;
import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
public class MainActivity extends SleepActivity {
 private SleepDialView view;
 private MaterialButton primary,stop,extend;
 private LinearLayout actions,root;
 private MaterialToolbar bar;
 private boolean pendingStart;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final Runnable ticker=new Runnable(){public void run(){update();handler.postDelayed(this,500);}};
 @Override public void onCreate(Bundle saved){super.onCreate(saved);SleepTimerStore.prefs(this).edit().remove("dnd").apply();
  root=SleepUi.root(this);bar=new MaterialToolbar(this);bar.setBackgroundColor(0xff080e16);
  bar.setNavigationIcon(R.drawable.ic_appearance);bar.setNavigationContentDescription(R.string.appearance);bar.setNavigationOnClickListener(v->SleepUi.appearance(this));
  bar.getMenu().add(0,1,0,R.string.settings).setIcon(R.drawable.ic_settings).setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);bar.setOnMenuItemClickListener(item->{openSettings();return true;});root.addView(bar,new LinearLayout.LayoutParams(-1,SleepUi.dp(this,52)));
  view=new SleepDialView(this);root.addView(view,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.VERTICAL);bottom.setPadding(SleepUi.dp(this,28),8,SleepUi.dp(this,28),SleepUi.dp(this,12));root.addView(bottom);
  primary=SleepUi.button(this,R.string.start,true);primary.setTag("timer_primary");bottom.addView(primary,new LinearLayout.LayoutParams(-1,SleepUi.dp(this,54)));primary.setOnClickListener(v->{if(SleepTimerStore.running(this)){SleepTimerStore.pause(this);toast(R.string.paused_message);}else startTimer();update();});
  actions=new LinearLayout(this);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,SleepUi.dp(this,58));ap.topMargin=SleepUi.dp(this,10);bottom.addView(actions,ap);
  stop=SleepUi.button(this,R.string.stop,false);extend=SleepUi.button(this,R.string.extend,false);stop.setTag("timer_stop");extend.setTag("timer_extend");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-1,1);bp.setMargins(4,0,4,0);actions.addView(stop,bp);actions.addView(extend,new LinearLayout.LayoutParams(bp));stop.setOnClickListener(v->stopTimer());extend.setOnClickListener(v->extendTimer());
  TextView footer=SleepUi.text(this,R.string.peaceful,13);footer.setGravity(android.view.Gravity.CENTER);bottom.addView(footer);update();
 }
 void update(){if(view==null)return;boolean running=SleepTimerStore.running(this),paused=SleepTimerStore.paused(this);int theme=SleepThemes.selected(this);int bg=theme==2?0xff06131f:0xff090b0e;root.setBackgroundColor(bg);bar.setBackgroundColor(bg);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
  primary.setBackgroundTintList(android.content.res.ColorStateList.valueOf(theme==2?0xff163f44:theme==1?0xffd5d7d9:0xfff2eee5));primary.setTextColor(theme==2?0xffc6f3ea:0xff141b22);
  primary.setText(running?R.string.pause:paused?R.string.resume:R.string.start);actions.setVisibility(running||paused?android.view.View.VISIBLE:android.view.View.GONE);extend.setEnabled(running);view.invalidate();}
 @Override protected void onResume(){super.onResume();SleepTimerStore.reconcile(this);handler.removeCallbacks(ticker);handler.post(ticker);if(pendingStart){pendingStart=false;if(SleepTimerStore.hasExactAlarmPermission(this))handler.post(this::startTimer);else toast(R.string.exact_needed);}}
 @Override protected void onPause(){handler.removeCallbacks(ticker);super.onPause();}
 public void openSettings(){startActivity(new Intent(this,SettingsActivity.class));}
 public void startTimer(){if(SleepTimerStore.running(this))return;
  if(Build.VERSION.SDK_INT>=31&&!SleepTimerStore.hasExactAlarmPermission(this)){pendingStart=true;toast(R.string.exact_needed);try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception e){pendingStart=false;openSettings();}return;}
  String missing=missingRequiredPermissions();
  if(!missing.isEmpty())new MaterialAlertDialogBuilder(this).setTitle(R.string.missing_title).setMessage(getString(R.string.missing_message,missing)).setPositiveButton(R.string.settings,(d,w)->openSettings()).setNegativeButton(R.string.timer_only,(d,w)->startUnchecked()).show();else startUnchecked();
 }
 private String missingRequiredPermissions(){StringBuilder b=new StringBuilder();
  if(SleepTimerStore.option(this,"lock_screen",false)&&!SleepActions.adminEnabled(this))b.append("• ").append(getString(R.string.lock_screen)).append('\n');
  if(SleepTimerStore.option(this,"silent_phone",false)&&!SleepActions.notificationPolicyGranted(this))b.append("• ").append(getString(R.string.silent_phone)).append('\n');
  if(SleepTimerStore.option(this,"pause_media",false)&&!SettingsActivity.listenerEnabled(this))b.append("• ").append(getString(R.string.media_access)).append('\n');
  if(SleepTimerStore.option(this,"go_home",false)&&!SettingsActivity.accessibilityEnabled(this))b.append("• ").append(getString(R.string.go_home)).append('\n');return b.toString();
 }
 private void startUnchecked(){boolean ok=SleepTimerStore.paused(this)?SleepTimerStore.resume(this):SleepTimerStore.start(this,view.chosenMinutes());if(ok){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},19);toast(R.string.started);}else toast(R.string.start_failed);update();}
 public void stopTimer(){SleepTimerStore.cancel(this);toast(R.string.stopped);update();}
 public void extendTimer(){toast(SleepTimerStore.extend(this)?R.string.extended:R.string.extend_failed);update();}
 private void toast(int text){Toast.makeText(this,text,Toast.LENGTH_SHORT).show();}
}
