package com.robo.sleep;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.content.SharedPreferences;

public final class SleepTimerStore {
    private SleepTimerStore() { }
    private static final String PREFS = "sleep_settings";
    public static final String STOP_ACTION = "com.robo.sleep.STOP";
    public static final String FINISH_ACTION = "com.robo.sleep.FINISH";
    public static final String EXTEND_ACTION = "com.robo.sleep.EXTEND";
    public static final String REFRESH_ACTION = "com.robo.sleep.REFRESH";
    private static final int ALARM_ID = 921;
    private static final int NOTIFICATION_ID = 922;
    private static final String CHANNEL_ID = "sleep_timer";

    public static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    public static boolean option(Context c, String key, boolean initial) { return prefs(c).getBoolean(key, initial); }
    public static void setOption(Context c, String key, boolean value) { prefs(c).edit().putBoolean(key, value).apply(); }
    public static long finishAt(Context c) { return prefs(c).getLong("finish_elapsed", 0L); }
    public static long token(Context c) { return prefs(c).getLong("timer_generation", 0L); }
    public static boolean running(Context c) { return finishAt(c) > 0L; }
    public static long remainMs(Context c) { return Math.max(0L, finishAt(c) - SystemClock.elapsedRealtime()); }
    public static boolean hasExactAlarmPermission(Context c) {
        AlarmManager a = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return Build.VERSION.SDK_INT < 31 || a.canScheduleExactAlarms();
    }
    private static PendingIntent alarmIntent(Context c) {
        return alarmIntent(c, token(c));
    }
    private static PendingIntent alarmIntent(Context c, long generation) {
        Intent intent = new Intent(c, SleepAlarmReceiver.class).setAction(FINISH_ACTION).setData(android.net.Uri.parse("sleep://timer/" + generation)).putExtra("timer_token", generation);
        return PendingIntent.getBroadcast(c, ALARM_ID, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    public static long durationMs(Context c) {
        return paused(c) ? Math.max(60_000L,prefs(c).getLong("paused_duration",60_000L)) : Math.max(60_000L, finishAt(c) - prefs(c).getLong("started_elapsed", finishAt(c)));
    }
    public static boolean paused(Context c){return pausedMs(c)>0;}
    public static long pausedMs(Context c){return prefs(c).getLong("paused_remaining",0L);}
    public static synchronized boolean pause(Context c){
        long remaining=remainMs(c);if(!running(c)||remaining<=0)return false;
        long duration=durationMs(c),generation=token(c);
        if(!prefs(c).edit().putLong("paused_remaining",remaining).putLong("paused_duration",duration)
            .remove("finish_elapsed").remove("started_elapsed").putLong("timer_generation",generation+1).commit())return false;
        PendingIntent alarm=alarmIntent(c,generation);((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(alarm);alarm.cancel();cancelRefresh(c,generation);
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTIFICATION_ID);return true;
    }
    public static synchronized boolean resume(Context c){
        long remaining=pausedMs(c);if(remaining<=0||running(c)||!hasExactAlarmPermission(c))return false;
        long generation=token(c)+1,deadline=SystemClock.elapsedRealtime()+remaining;
        long duration=durationMs(c);PendingIntent alarm=alarmIntent(c,generation);
        AlarmManager manager=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        try{manager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,deadline,alarm);}catch(SecurityException e){alarm.cancel();return false;}
        if(!prefs(c).edit().putLong("finish_elapsed",deadline).putLong("started_elapsed",deadline-duration).putLong("timer_generation",generation).remove("paused_remaining").remove("paused_duration").commit()){manager.cancel(alarm);alarm.cancel();return false;}
        refreshNotification(c);return true;
    }
    /** Add to the current deadline, never restart or revive an expired timer. */
    public static synchronized boolean extend(Context c) {
        if (!running(c) || remainMs(c) <= 0L || !hasExactAlarmPermission(c)) return false;
        long previousToken = token(c), nextToken = previousToken + 1L;
        long deadline = finishAt(c) + 600_000L;
        AlarmManager manager = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent replacement = alarmIntent(c, nextToken);
        try {
            manager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, deadline, replacement);
        } catch (SecurityException e) { replacement.cancel(); return false; }
        if (!prefs(c).edit().putLong("finish_elapsed", deadline).putLong("timer_generation", nextToken).commit()) {
            manager.cancel(replacement); replacement.cancel(); return false;
        }
        PendingIntent previous = alarmIntent(c, previousToken);
        manager.cancel(previous); previous.cancel();
        cancelRefresh(c, previousToken);
        refreshNotification(c);
        return true;
    }
    public static synchronized boolean start(Context c, int minutes) {
        if (!hasExactAlarmPermission(c)) return false;
        minutes = Math.max(1, Math.min(90, minutes));
        if (running(c) || paused(c)) return false;
        cancel(c);
        long t = SystemClock.elapsedRealtime() + minutes * 60_000L;
        boolean saved = prefs(c).edit().putLong("finish_elapsed", t).putLong("started_elapsed", SystemClock.elapsedRealtime())
            .putInt("chosen_minutes", minutes).putLong("timer_generation", token(c)+1L).commit();
        if (!saved) return false;
        AlarmManager manager = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        try { manager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, t, alarmIntent(c)); }
        catch (SecurityException e) { clear(c); return false; }
        refreshNotification(c);
        return true;
    }
    public static void rearm(Context c) {
        if (!running(c) || !hasExactAlarmPermission(c)) return;
        try {
            AlarmManager manager = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            manager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, finishAt(c), alarmIntent(c));
        } catch (SecurityException ignored) { }
    }
    public static boolean clear(Context c) {
        cancelRefresh(c, token(c));
        boolean claimed = prefs(c).edit().remove("finish_elapsed").remove("started_elapsed").remove("paused_remaining").remove("paused_duration").commit();
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTIFICATION_ID);
        return claimed;
    }
    public static synchronized void cancel(Context c) {
        AlarmManager manager = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent alarm = alarmIntent(c);
        manager.cancel(alarm);
        alarm.cancel();
        clear(c);
    }
    public static void reconcile(Context c) {
        if (!running(c)) return;
        Intent i = new Intent(c, SleepAlarmReceiver.class).setAction(FINISH_ACTION)
            .setData(android.net.Uri.parse("sleep://timer/" + token(c)));
        PendingIntent alarm = PendingIntent.getBroadcast(c, ALARM_ID, i,
            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (alarm == null || !hasExactAlarmPermission(c)) clear(c);
        else if (remainMs(c)>0) refreshNotification(c);
    }
    private static PendingIntent refreshIntent(Context c, long generation) {
        Intent i=new Intent(c,SleepAlarmReceiver.class).setAction(REFRESH_ACTION)
            .setData(android.net.Uri.parse("sleep://refresh/"+generation)).putExtra("timer_token",generation);
        return PendingIntent.getBroadcast(c,923,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    }
    private static void cancelRefresh(Context c,long generation) {
        PendingIntent pi=refreshIntent(c,generation);
        ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pi); pi.cancel();
    }
    static long nextMinuteDelay(long remaining) {
        long fraction=remaining%60_000L;
        return fraction==0?60_000L:fraction;
    }
    /** Cosmetic, non-wakeup updates never consume the idle wakeup quota of the expiry alarm. */
    public static void refreshNotification(Context c) {
        long remaining=remainMs(c);
        if(!running(c)||remaining<=0) return;
        notifyOngoing(c,(int)((remaining+59_999L)/60_000L));
        long delay=nextMinuteDelay(remaining);
        if(delay>=remaining) { cancelRefresh(c,token(c)); return; }
        try {
            ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setExact(
                AlarmManager.ELAPSED_REALTIME,SystemClock.elapsedRealtime()+delay,refreshIntent(c,token(c)));
        } catch(SecurityException ignored) { }
    }
    private static void notifyOngoing(Context c, int minutes) {
        c=SleepLocale.context(c);
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, c.getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent openIntent = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(c, SleepAlarmReceiver.class).setAction(STOP_ACTION)
            .setData(android.net.Uri.parse("sleep://stop/"+token(c))).putExtra("timer_token", token(c));
        PendingIntent stopIntent = PendingIntent.getBroadcast(c, 2, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent extend=new Intent(c,SleepAlarmReceiver.class).setAction(EXTEND_ACTION)
            .setData(android.net.Uri.parse("sleep://extend/"+token(c))).putExtra("timer_token",token(c));
        PendingIntent extendIntent=PendingIntent.getBroadcast(c,3,extend,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CHANNEL_ID)
            .setContentTitle(c.getString(R.string.notification_title))
            .setContentText(c.getString(R.string.remaining,minutes))
            .setShowWhen(false)
            .setWhen(System.currentTimeMillis())
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(openIntent).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, c.getString(R.string.stop), stopIntent).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_recent_history, c.getString(R.string.extend), extendIntent).build())
            .build();
        try { nm.notify(NOTIFICATION_ID, n); } catch (SecurityException ignored) { }
    }
}
