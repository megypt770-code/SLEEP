package com.robo.sleep;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class SleepAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        long token = intent.getLongExtra("timer_token", -1L);
        if (!SleepTimerStore.running(context) || token != SleepTimerStore.token(context) || token <= 0L) return;
        if (SleepTimerStore.STOP_ACTION.equals(intent.getAction())) {
            SleepTimerStore.cancel(context); return;
        }
        if (SleepTimerStore.EXTEND_ACTION.equals(intent.getAction())) {
            SleepTimerStore.extend(context); return;
        }
        if (SleepTimerStore.REFRESH_ACTION.equals(intent.getAction())) {
            SleepTimerStore.refreshNotification(context); return;
        }
        if (!SleepTimerStore.FINISH_ACTION.equals(intent.getAction())) return;
        if (SleepTimerStore.remainMs(context) > 0L) {
            SleepTimerStore.rearm(context); return;
        }
        // Serialize Stop and completion on the application main thread. Persist
        // the claim before any action so redelivery cannot execute it twice.
        if (SleepTimerStore.clear(context)) SleepActions.perform(context);
    }
}
