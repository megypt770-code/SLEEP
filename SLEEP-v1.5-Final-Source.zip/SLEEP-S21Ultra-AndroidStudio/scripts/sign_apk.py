#!/usr/bin/env python3
"""Sign a release APK using the original SLEEP signing backup."""
import argparse
from pathlib import Path
import subprocess
import tempfile
parser=argparse.ArgumentParser()
parser.add_argument('--build-tools',required=True)
parser.add_argument('--keystore',required=True)
parser.add_argument('--password-file',required=True)
parser.add_argument('--input',required=True)
parser.add_argument('--output',required=True)
a=parser.parse_args()
with tempfile.TemporaryDirectory() as tmp:
    aligned=str(Path(tmp)/'aligned.apk')
    subprocess.run([str(Path(a.build_tools)/'zipalign'),'-f','-p','4',a.input,aligned],check=True)
    subprocess.run([str(Path(a.build_tools)/'apksigner'),'sign','--ks',a.keystore,'--ks-key-alias','sleep-release','--ks-pass','file:'+a.password_file,'--v4-signing-enabled','false','--out',a.output,aligned],check=True)
subprocess.run([str(Path(a.build_tools)/'apksigner'),'verify','--verbose',a.output],check=True)
